# Grok 账号批量注册工具

基于 [DrissionPage](https://github.com/g1879/DrissionPage) 的 Grok (x.ai) 账号自动注册脚本，使用 [DuckMail](https://duckmail.sbs) 临时邮箱接收验证码，通过 Chrome 扩展修复 CDP `MouseEvent.screenX/screenY` 缺陷绕过 Cloudflare Turnstile。

注册完成后自动推送 SSO token 到 [grok2api](https://github.com/chenyme/grok2api) 号池。

## 特性

- DuckMail 临时邮箱（`curl_cffi` TLS 指纹伪装）
- Cloudflare Turnstile 自动绕过（Chrome 扩展 patch + DrissionPage shadow_root 链式点击）
- 无头服务器支持（Xvfb 虚拟显示器，自动检测 Linux 环境）
- 中英文界面自动适配
- 自动推送 SSO token 到 grok2api（支持 append 合并模式）
- 环境变量 / config.json 双重配置，优先级：环境变量 > config.json > 默认值

---

## 环境要求

- Python 3.10+
- Chromium 或 Chrome 浏览器
- [DuckMail](https://duckmail.sbs) 账号
- 可选：[grok2api](https://github.com/chenyme/grok2api) 实例

---

## 安装

```bash
pip install -r requirements.txt
```

无头服务器（Linux）额外安装：

```bash
apt install -y xvfb
# 推荐用 playwright 装 chromium（避免 snap 版 AppArmor 限制）
pip install playwright && python -m playwright install chromium && python -m playwright install-deps chromium
```

---

## 配置

```bash
cp config.example.json config.json
# 编辑 config.json，填写 duckmail_bearer
```

或使用环境变量：

```bash
cp .env.example .env
# 编辑 .env
```

### config.json 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `run.count` | int | 注册轮数，`0` 为无限循环 |
| `duckmail_api_base` | string | DuckMail API 地址 |
| `duckmail_bearer` | string | DuckMail Bearer Token（[获取方式](#获取-duckmail-bearer-token)） |
| `proxy` | string | DuckMail API 请求代理（可选） |
| `browser_proxy` | string | 浏览器代理（可选） |
| `api.endpoint` | string | grok2api 管理接口地址，留空跳过推送 |
| `api.token` | string | grok2api 的 `app_key` |
| `api.append` | bool | `true` 合并线上 token，`false` 覆盖 |

---

## 获取 DuckMail Bearer Token

1. 打开 [duckmail.sbs](https://duckmail.sbs) 注册登录
2. F12 → Network → 刷新页面
3. 找到发往 `api.duckmail.sbs` 的任意请求
4. 复制 `Authorization: Bearer <token>` 中的 token

---

## 启动

```bash
# 按 config.json 中的 run.count 执行
python DrissionPage_example.py

# 指定轮数
python DrissionPage_example.py --count 50

# 无限循环
python DrissionPage_example.py --count 0
```

---

## 输出

```
sso/sso.txt       ← 每行一个 SSO token（追加写入）
logs/run_*.log    ← 每次运行的详细日志
```

---

## 文件结构

```
├── DrissionPage_example.py     # 主脚本
├── email_register.py           # DuckMail 临时邮箱封装
├── config.json                 # 配置文件（不入库）
├── config.example.json         # 配置模板
├── .env.example                # 环境变量模板
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── turnstilePatch/             # Chrome 扩展（Turnstile patch v2.2）
│   ├── manifest.json
│   └── script.js
├── scripts/
│   ├── docker-build.sh
│   └── docker-run.sh
├── sso/                        # SSO token 输出（自动创建）
└── logs/                       # 运行日志（自动创建）
```

---

## Docker 部署

```bash
# 构建
docker-compose build

# 运行（需设置 DUCKMAIL_BEARER）
export DUCKMAIL_BEARER=your_token_here
docker-compose up

# 指定轮数
REGISTER_COUNT=50 docker-compose up
```

---

## 无头服务器注意事项

- snap 版 chromium 在 root 下有 AppArmor 限制，推荐用 playwright 安装的 chromium
- 服务器需翻墙时，在 `browser_proxy` 填写代理地址
- 脚本自动检测 Linux 环境并使用 playwright chromium 路径

---

## 致谢

- [kevinr229/grok-maintainer](https://github.com/kevinr229/grok-maintainer) — 原始项目
- [grok2api](https://github.com/chenyme/grok2api) — Grok API 代理
- [DuckMail](https://duckmail.sbs) — 临时邮箱服务
