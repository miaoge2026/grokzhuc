"""
Grok 自动注册主脚本
基于 DrissionPage 实现 x.ai 账号自动注册，支持环境变量配置、结构化日志和健壮性增强
"""

from __future__ import annotations

import argparse
import datetime
import json
import logging
import os
import secrets
import shutil
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from DrissionPage import Chromium, ChromiumOptions
from DrissionPage.errors import PageDisconnectedError

from email_register import get_email_and_token, get_oai_code, DuckMailConfig

# ============================================================
# 配置管理
# ============================================================


@dataclass
class AppConfig:
    """应用配置数据类"""
    run_count: int = 10
    log_level: str = "INFO"
    output_dir: str = "sso"

    browser_proxy: str = ""
    headless: bool = True
    user_data_dir: str = "./chrome_data"
    chromium_path: Optional[str] = None

    duckmail_config: DuckMailConfig = field(default_factory=DuckMailConfig)

    api_endpoint: str = ""
    api_token: str = ""
    api_append: bool = True

    # 超时配置（秒）
    email_timeout: int = 30
    code_timeout: int = 180
    profile_timeout: int = 120
    sso_timeout: int = 120
    page_load_timeout: int = 15

    max_retries: int = 3
    retry_delay: float = 2.0

    @classmethod
    def load(cls) -> AppConfig:
        config = cls()

        if os.getenv("RUN_COUNT"):
            config.run_count = int(os.getenv("RUN_COUNT"))
        if os.getenv("LOG_LEVEL"):
            config.log_level = os.getenv("LOG_LEVEL")
        if os.getenv("BROWSER_PROXY"):
            config.browser_proxy = os.getenv("BROWSER_PROXY")
        if os.getenv("HEADLESS"):
            config.headless = os.getenv("HEADLESS").lower() == "true"
        if os.getenv("GROK2API_ENDPOINT"):
            config.api_endpoint = os.getenv("GROK2API_ENDPOINT")
        if os.getenv("GROK2API_TOKEN"):
            config.api_token = os.getenv("GROK2API_TOKEN")
        if os.getenv("GROK2API_APPEND"):
            config.api_append = os.getenv("GROK2API_APPEND").lower() == "true"

        config_path = Path(__file__).parent / "config.json"
        if config_path.exists():
            with config_path.open("r", encoding="utf-8") as f:
                conf = json.load(f)

            if not os.getenv("RUN_COUNT"):
                config.run_count = conf.get("run", {}).get("count", 10)
            if not os.getenv("BROWSER_PROXY"):
                config.browser_proxy = conf.get("browser_proxy", "")
            if not os.getenv("GROK2API_ENDPOINT"):
                config.api_endpoint = conf.get("api", {}).get("endpoint", "")
            if not os.getenv("GROK2API_TOKEN"):
                config.api_token = conf.get("api", {}).get("token", "")
            if not os.getenv("GROK2API_APPEND"):
                config.api_append = conf.get("api", {}).get("append", True)

        return config


# ============================================================
# 日志配置
# ============================================================


def setup_logger(config: AppConfig) -> logging.Logger:
    log_level = getattr(logging, config.log_level.upper(), logging.INFO)

    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"run_{ts}.log"

    logger = logging.getLogger("grok_register")
    logger.setLevel(log_level)
    logger.handlers.clear()

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(log_level)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(log_level)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    logger.info(f"日志初始化完成，路径：{log_path}")
    return logger


# ============================================================
# 数据类
# ============================================================


@dataclass
class BrowserState:
    browser: Optional[Chromium] = None
    page: Optional[Any] = None
    user_data_dir: Path = field(default_factory=lambda: Path("./chrome_data"))


class RegistrationResult:
    def __init__(
        self,
        email: str,
        password: str,
        given_name: str,
        family_name: str,
        sso: str,
        success: bool = True,
        error: Optional[str] = None
    ):
        self.email = email
        self.password = password
        self.given_name = given_name
        self.family_name = family_name
        self.sso = sso
        self.success = success
        self.error = error
        self.timestamp = datetime.datetime.now().isoformat()


# ============================================================
# Python 运行时检查
# ============================================================


def ensure_stable_python_runtime() -> None:
    if sys.version_info < (3, 14) or os.environ.get("DPE_REEXEC_DONE") == "1":
        return

    local_app_data = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        os.path.join(local_app_data, "Programs", "Python", "Python312", "python.exe"),
        os.path.join(local_app_data, "Programs", "Python", "Python313", "python.exe"),
    ]

    current_python = os.path.normcase(os.path.abspath(sys.executable))
    for candidate in candidates:
        if not os.path.isfile(candidate):
            continue
        if os.path.normcase(os.path.abspath(candidate)) == current_python:
            return
        print(f"[*] 检测到 Python {sys.version.split()[0]}，自动切换到更稳定的解释器：{candidate}")
        env = os.environ.copy()
        env["DPE_REEXEC_DONE"] = "1"
        os.execve(candidate, [candidate, os.path.abspath(__file__), *sys.argv[1:]], env)


def warn_runtime_compatibility() -> None:
    if sys.version_info >= (3, 14):
        print("[提示] 当前 Python 为 3.14+；若出现 Mail.tm TLS 异常，建议改用 Python 3.12 或 3.13。")


# ============================================================
# 浏览器管理
# ============================================================


def setup_browser_options(config: AppConfig) -> ChromiumOptions:
    co = ChromiumOptions()
    co.auto_port()
    co.set_argument("--no-sandbox")
    co.set_argument("--disable-gpu")
    co.set_argument("--disable-dev-shm-usage")
    co.set_argument("--disable-software-rasterizer")
    co.set_argument("--disable-blink-features=AutomationControlled")
    co.set_argument(
        "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    )
    co.set_argument("--disable-features=IsolateOrigins,site-per-process")
    co.set_argument("--window-size=1280,800")

    co.set_timeouts(base=1, page_load=30, script=15)

    if config.browser_proxy:
        co.set_proxy(config.browser_proxy)
        print(f"[*] 浏览器代理：{config.browser_proxy}")

    if sys.platform == "linux":
        import glob
        pw_chromes = glob.glob(
            os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome")
        )
        if pw_chromes:
            co.set_browser_path(pw_chromes[0])
            print(f"[*] 使用 Playwright Chromium：{pw_chromes[0]}")
        else:
            for candidate in [
                "/usr/bin/chromium-browser",
                "/usr/bin/chromium",
                "/usr/bin/google-chrome",
            ]:
                if os.path.isfile(candidate):
                    co.set_browser_path(candidate)
                    print(f"[*] 使用系统 Chromium：{candidate}")
                    break

        user_data = Path(__file__).parent / config.user_data_dir
        user_data.mkdir(exist_ok=True)
        co.set_user_data_path(str(user_data))

    ext_path = Path(__file__).parent / "turnstilePatch"
    if ext_path.exists():
        co.add_extension(str(ext_path))
        print(f"[*] 已加载 Turnstile 扩展：{ext_path}")
    else:
        print("[!] 警告：未找到 turnstilePatch 扩展，Turnstile 可能无法通过")

    return co


def start_browser(options: ChromiumOptions, state: BrowserState) -> None:
    if state.user_data_dir.exists():
        shutil.rmtree(state.user_data_dir, ignore_errors=True)
    state.user_data_dir.mkdir(exist_ok=True)

    state.browser = Chromium(options)
    tabs = state.browser.get_tabs()
    state.page = tabs[-1] if tabs else state.browser.new_tab()
    time.sleep(1)
    print("[*] 浏览器启动成功")


def stop_browser(state: BrowserState) -> None:
    if state.browser is not None:
        try:
            state.browser.quit()
        except Exception:
            pass
    state.browser = None
    state.page = None


def restart_browser(options: ChromiumOptions, state: BrowserState) -> None:
    stop_browser(state)
    start_browser(options, state)


def _get_active_page(state: BrowserState) -> Any:
    """安全获取当前活动页面，失败时新建标签页"""
    try:
        tabs = state.browser.get_tabs()
        if tabs:
            state.page = tabs[-1]
            return state.page
    except Exception:
        pass
    state.page = state.browser.new_tab()
    return state.page


def safe_run_js(state: BrowserState, script: str, *args, timeout: int = 10) -> Any:
    """
    安全执行 JS，自动处理 ContextLostError / PageDisconnectedError。
    ContextLostError 说明页面正在刷新，等待后重试一次。
    """
    from DrissionPage.errors import ContextLostError
    try:
        return state.page.run_js(script, *args, timeout=timeout)
    except ContextLostError:
        print("[*] 页面上下文丢失，等待加载后重试...")
        try:
            state.page.wait.load_start(timeout=5)
        except Exception:
            pass
        time.sleep(2)
        try:
            return state.page.run_js(script, *args, timeout=timeout)
        except Exception:
            return None
    except PageDisconnectedError:
        _get_active_page(state)
        return None
    except Exception as e:
        print(f"[*] JS 执行异常：{str(e)[:80]}")
        return None


# ============================================================
# 页面操作
# ============================================================

SIGNUP_URL = "https://accounts.x.ai/sign-up?redirect=grok-com"


def open_signup_page(state: BrowserState, config: AppConfig) -> None:
    """打开注册页并等待页面稳定"""
    _get_active_page(state)
    assert state.page is not None

    try:
        state.page.get(SIGNUP_URL)
    except Exception:
        _get_active_page(state)
        state.page = state.browser.new_tab(SIGNUP_URL)

    _wait_page_stable(state, timeout=config.page_load_timeout)
    click_email_signup_button(state)


def _wait_page_stable(state: BrowserState, timeout: int = 15) -> None:
    """等待 document.readyState === complete"""
    assert state.page is not None
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            ready = state.page.run_js(
                "return document.readyState === 'complete'", timeout=3
            )
            if ready:
                time.sleep(1)  # 额外等待 React 渲染
                return
        except Exception:
            pass
        time.sleep(0.5)
    time.sleep(2)  # 超时也继续，页面可能已部分可用


def click_email_signup_button(state: BrowserState, timeout: int = 20) -> bool:
    """
    点击"使用邮箱注册"按钮。
    修复：移除对 is_alive 等不存在属性的依赖，改用纯 JS + DrissionPage 双重尝试。
    每 3 次未找到按钮则刷新页面重试。
    """
    deadline = time.time() + timeout
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        assert state.page is not None

        # 方式 1：JS 点击
        clicked = safe_run_js(state, r"""
const candidates = Array.from(
    document.querySelectorAll('button, a, [role="button"], input[type="button"]')
);
const target = candidates.find((node) => {
    const text = (node.innerText || node.textContent || '')
        .replace(/\s+/g, '').toLowerCase();
    return (
        text.includes('使用邮箱注册') ||
        text.includes('signupwithemail') ||
        text.includes('signupemail') ||
        text.includes('continuewith email') ||
        text.includes('email')
    );
});
if (!target) { return false; }
target.click();
return true;
        """, timeout=5)

        if clicked:
            print("[*] 已点击邮箱注册按钮")
            time.sleep(1.5)
            return True

        # 方式 2：DrissionPage 原生定位
        try:
            btn = state.page.ele(
                'xpath://button[contains(., "邮箱") or contains(., "email") '
                'or contains(., "Email")]',
                timeout=2
            )
            if btn:
                btn.click()
                print("[*] 已通过原生方式点击邮箱注册按钮")
                time.sleep(1.5)
                return True
        except Exception:
            pass

        # 检查是否已显示邮箱输入框（部分情况页面默认直接到此步）
        has_email_input = safe_run_js(state, r"""
const inp = document.querySelector(
    'input[type="email"], input[name="email"], input[data-testid="email"]'
);
return !!(inp && inp.offsetParent !== null);
        """, timeout=3)
        if has_email_input:
            print("[*] 页面已显示邮箱输入框，跳过按钮点击")
            return True

        if attempt % 3 == 0:
            print(f"[*] 第 {attempt} 次尝试未找到按钮，刷新页面...")
            try:
                state.page.get(SIGNUP_URL)
                _wait_page_stable(state, timeout=10)
            except Exception:
                pass

        time.sleep(1)

    print("[!] 未找到邮箱注册按钮，继续后续步骤")
    return False


def fill_email_and_submit(state: BrowserState, timeout: int = 30) -> Tuple[str, str]:
    """填写邮箱并提交"""
    email, dev_token = get_email_and_token()
    if not email or not dev_token:
        raise Exception("获取邮箱失败")

    deadline = time.time() + timeout
    while time.time() < deadline:
        assert state.page is not None

        filled = safe_run_js(state, """
const email = arguments[0];

function isVisible(node) {
    if (!node) { return false; }
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
        return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
}

const input = Array.from(document.querySelectorAll(
    'input[data-testid="email"], input[name="email"], ' +
    'input[type="email"], input[autocomplete="email"]'
)).find(n => isVisible(n) && !n.disabled && !n.readOnly) || null;

if (!input) { return 'not-ready'; }

input.focus();
input.click();

const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
const tracker = input._valueTracker;
if (tracker) { tracker.setValue(''); }
if (valueSetter) { valueSetter.call(input, email); }
else { input.value = email; }

input.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, data: email, inputType: 'insertText' }));
input.dispatchEvent(new InputEvent('input', { bubbles: true, data: email, inputType: 'insertText' }));
input.dispatchEvent(new Event('change', { bubbles: true }));

if ((input.value || '').trim() !== email || !input.checkValidity()) { return false; }

input.blur();
return 'filled';
        """, email, timeout=8)

        if filled == 'not-ready':
            time.sleep(0.5)
            continue

        if filled != 'filled':
            print(f"[Debug] 邮箱写入失败：{filled}")
            time.sleep(0.5)
            continue

        time.sleep(0.8)

        clicked = safe_run_js(state, r"""
function isVisible(node) {
    if (!node) { return false; }
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
        return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
}

const input = Array.from(document.querySelectorAll(
    'input[data-testid="email"], input[name="email"], ' +
    'input[type="email"], input[autocomplete="email"]'
)).find(n => isVisible(n) && !n.disabled && !n.readOnly) || null;

if (!input || !input.checkValidity() || !(input.value || '').trim()) { return false; }

const buttons = Array.from(
    document.querySelectorAll('button[type="submit"], button')
).filter(n => isVisible(n) && !n.disabled && n.getAttribute('aria-disabled') !== 'true');

const submitButton = buttons.find(n => {
    const text = (n.innerText || n.textContent || '').replace(/\s+/g, '');
    const t = text.toLowerCase();
    return text === '注册' || text.includes('注册') ||
           t === 'signup' || t === 'sign up' || t.includes('sign up') ||
           t.includes('continue') || t.includes('next');
});

if (!submitButton || submitButton.disabled) { return false; }
submitButton.click();
return true;
        """, timeout=5)

        if clicked:
            print(f"[*] 已填写邮箱并点击注册：{email}")
            return email, dev_token

        time.sleep(0.5)

    raise Exception("未找到邮箱输入框或注册按钮")


def fill_code_and_submit(
    state: BrowserState,
    email: str,
    dev_token: str,
    timeout: int = 180
) -> str:
    """填写验证码并提交"""
    code = get_oai_code(dev_token, email, timeout=timeout)
    if not code:
        raise Exception("获取验证码失败")

    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            assert state.page is not None

            filled = state.page.run_js("""
const code = String(arguments[0] || '').trim();

function isVisible(node) {
    if (!node) { return false; }
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
        return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
}

function setNativeValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    const tracker = input._valueTracker;
    if (tracker) { tracker.setValue(''); }
    if (setter) { setter.call(input, ''); setter.call(input, value); }
    else { input.value = ''; input.value = value; }
}

function dispatchInputEvents(input, value) {
    input.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, data: value, inputType: 'insertText' }));
    input.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: value, inputType: 'insertText' }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
}

const input = Array.from(document.querySelectorAll(
    'input[data-input-otp="true"], input[name="code"], ' +
    'input[autocomplete="one-time-code"], input[inputmode="numeric"], input[inputmode="text"]'
)).find(n => isVisible(n) && !n.disabled && !n.readOnly && Number(n.maxLength || code.length || 6) > 1) || null;

const otpBoxes = Array.from(document.querySelectorAll('input')).filter(n => {
    if (!isVisible(n) || n.disabled || n.readOnly) { return false; }
    const ml = Number(n.maxLength || 0);
    const ac = String(n.autocomplete || '').toLowerCase();
    return ml === 1 || ac === 'one-time-code';
});

if (!input && otpBoxes.length < code.length) { return 'not-ready'; }

if (input) {
    input.focus();
    input.click();
    setNativeValue(input, code);
    dispatchInputEvents(input, code);
    const val = String(input.value || '').trim();
    const expLen = Number(input.maxLength || code.length || 6);
    if (val !== code) { return 'aggregate-mismatch'; }
    if (expLen > 0 && val.length !== expLen) { return 'aggregate-length-mismatch'; }
    input.blur();
    return 'filled';
}

const ordered = otpBoxes.slice(0, code.length);
for (let i = 0; i < ordered.length; i++) {
    const box = ordered[i]; const char = code[i] || '';
    box.focus(); box.click();
    setNativeValue(box, char); dispatchInputEvents(box, char);
    box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: char }));
    box.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: char }));
    box.blur();
}

const merged = ordered.map(n => String(n.value || '').trim()).join('');
return merged === code ? 'filled' : 'box-mismatch';
            """, code)

        except PageDisconnectedError:
            _get_active_page(state)
            if has_profile_form(state):
                print("[*] 验证码提交后已跳转到最终注册页。")
                return code
            time.sleep(1)
            continue

        if filled == 'not-ready':
            if has_profile_form(state):
                print("[*] 已直接进入最终注册页，跳过验证码按钮确认。")
                return code
            time.sleep(0.5)
            continue

        if filled != 'filled':
            print(f"[Debug] 验证码写入失败：{filled}")
            time.sleep(0.5)
            continue

        time.sleep(1.2)
        try:
            clicked = state.page.run_js(r"""
function isVisible(node) {
    if (!node) { return false; }
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
        return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
}

const aggInput = Array.from(document.querySelectorAll(
    'input[data-input-otp="true"], input[name="code"], ' +
    'input[autocomplete="one-time-code"], input[inputmode="numeric"], input[inputmode="text"]'
)).find(n => isVisible(n) && !n.disabled && !n.readOnly && Number(n.maxLength || 0) > 1) || null;

let value = '';
if (aggInput) {
    value = String(aggInput.value || '').trim();
    const expLen = Number(aggInput.maxLength || value.length || 6);
    if (!value || (expLen > 0 && value.length !== expLen)) { return false; }
} else {
    const boxes = Array.from(document.querySelectorAll('input')).filter(n => {
        if (!isVisible(n) || n.disabled || n.readOnly) { return false; }
        const ml = Number(n.maxLength || 0);
        const ac = String(n.autocomplete || '').toLowerCase();
        return ml === 1 || ac === 'one-time-code';
    });
    value = boxes.map(n => String(n.value || '').trim()).join('');
    if (!value || value.length < 6) { return false; }
}

const buttons = Array.from(
    document.querySelectorAll('button[type="submit"], button')
).filter(n => isVisible(n) && !n.disabled && n.getAttribute('aria-disabled') !== 'true');

const confirmButton = buttons.find(n => {
    const text = (n.innerText || n.textContent || '').replace(/\s+/g, '');
    const t = text.toLowerCase();
    return text === '确认邮箱' || text.includes('确认邮箱') ||
           text === '继续' || text === '下一步' ||
           t.includes('confirm') || t.includes('continue') ||
           t.includes('next') || t.includes('verify');
});

if (!confirmButton) { return 'no-button'; }
confirmButton.focus();
confirmButton.click();
return 'clicked';
            """)
        except PageDisconnectedError:
            _get_active_page(state)
            if has_profile_form(state):
                print("[*] 确认邮箱后页面跳转成功。")
                return code
            clicked = 'disconnected'

        if clicked == 'clicked':
            print(f"[*] 已填写验证码并点击确认邮箱：{code}")
            time.sleep(2)
            _get_active_page(state)
            return code

        if clicked == 'no-button':
            current_url = getattr(state.page, 'url', '')
            if 'sign-up' in current_url or 'signup' in current_url:
                print(f"[*] 验证码已填写，页面自动跳转：{current_url}")
                return code

        if clicked == 'disconnected':
            time.sleep(1)
            continue

        time.sleep(0.5)

    raise Exception("未找到验证码输入框或确认邮箱按钮")


def has_profile_form(state: BrowserState) -> bool:
    """检查是否显示个人资料表单"""
    _get_active_page(state)
    result = safe_run_js(state, """
const g = document.querySelector('input[data-testid="givenName"], input[name="givenName"], input[autocomplete="given-name"]');
const f = document.querySelector('input[data-testid="familyName"], input[name="familyName"], input[autocomplete="family-name"]');
const p = document.querySelector('input[data-testid="password"], input[name="password"], input[type="password"]');
return !!(g && f && p);
    """, timeout=3)
    return bool(result)


# ============================================================
# Turnstile 处理
# ============================================================


def get_turnstile_token(state: BrowserState, timeout: int = 120) -> str:
    """
    获取 Turnstile token。

    优先级：
    1. turnstile.getResponse() 直接获取
    2. 隐藏 input[name="cf-turnstile-response"] 的值（扩展自动解决时）
    3. DrissionPage shadow_root 链式访问点击 checkbox（backup 验证的有效路径）
    4. JS contentDocument 回退
    """
    assert state.page is not None

    safe_run_js(state, "try { turnstile.reset() } catch(e) {}", timeout=3)
    start_time = time.time()
    print("[*] 开始处理 Turnstile...")

    for attempt in range(20):
        elapsed = int(time.time() - start_time)
        if elapsed >= timeout:
            break

        # 方法 1：直接获取
        token = safe_run_js(
            state,
            "try { return turnstile.getResponse() || null } catch(e) { return null }",
            timeout=3
        )
        if token and len(str(token)) > 20:
            print(f"[*] Turnstile 验证成功（直接获取）: {str(token)[:20]}...")
            return str(token)

        # 方法 2：隐藏 input（扩展自动填入）
        hidden_val = safe_run_js(state, """
const inp = document.querySelector('input[name="cf-turnstile-response"]');
return inp ? (inp.value || '') : '';
        """, timeout=3)
        if hidden_val and len(str(hidden_val)) > 20:
            print(f"[*] Turnstile 验证成功（隐藏 input）: {str(hidden_val)[:20]}...")
            return str(hidden_val)

        # 方法 3 & 4：主动点击（前 12 次尝试）
        if attempt < 12:
            try:
                _click_turnstile_checkbox(state)
            except Exception as e:
                print(f"[*] checkbox 点击异常：{str(e)[:50]}")

        print(f"[*] Turnstile 等待中... ({elapsed}s / 尝试 {attempt + 1}/20)")
        time.sleep(max(3, timeout // 20))

    raise Exception("failed to solve turnstile (timeout)")


def _click_turnstile_checkbox(state: BrowserState) -> bool:
    """
    通过 DrissionPage shadow_root 链式访问点击 Turnstile checkbox。
    恢复 backup 版本中已验证有效的路径。
    """
    assert state.page is not None

    # 方法 A：shadow_root 链式访问
    try:
        challenge_solution = state.page.ele('@name=cf-turnstile-response', timeout=2)
        if not challenge_solution:
            raise ValueError("未找到 cf-turnstile-response input")

        challenge_wrapper = challenge_solution.parent()
        if not challenge_wrapper:
            raise ValueError("未找到 wrapper")

        challenge_iframe = challenge_wrapper.shadow_root.ele("tag:iframe", timeout=2)
        if not challenge_iframe:
            raise ValueError("未找到 challenge iframe")

        # 注入鼠标坐标修复
        try:
            challenge_iframe.run_js("""
window.dtp = 1;
function ri(a,b){return Math.floor(Math.random()*(b-a+1))+a;}
Object.defineProperty(MouseEvent.prototype,'screenX',{value:ri(800,1200),configurable:true});
Object.defineProperty(MouseEvent.prototype,'screenY',{value:ri(400,600),configurable:true});
            """)
        except Exception:
            pass

        # 尝试 shadow_root 内的 checkbox
        try:
            iframe_body = challenge_iframe.ele("tag:body", timeout=2)
            if iframe_body:
                checkbox = iframe_body.shadow_root.ele("tag:input", timeout=2)
                if checkbox:
                    checkbox.click()
                    print("[*] 已通过 shadow_root 点击 Turnstile checkbox")
                    time.sleep(3)
                    return True
        except Exception:
            pass

        # 回退：直接点击 body 内的 input
        try:
            iframe_body = challenge_iframe.ele("tag:body", timeout=1)
            if iframe_body:
                checkbox = iframe_body.ele("tag:input", timeout=1)
                if checkbox:
                    checkbox.click()
                    print("[*] 已点击 Turnstile checkbox（direct body）")
                    time.sleep(3)
                    return True
        except Exception:
            pass

    except Exception as e:
        print(f"[*] shadow_root 方法失败：{str(e)[:60]}")

    # 方法 B：JS contentDocument 回退
    clicked = safe_run_js(state, """
try {
    for (const iframe of Array.from(document.querySelectorAll('iframe'))) {
        try {
            const doc = iframe.contentDocument || iframe.contentWindow?.document;
            if (!doc) { continue; }
            const cb = doc.querySelector('input[type="checkbox"]') ||
                       doc.querySelector('[role="checkbox"]') ||
                       doc.querySelector('input');
            if (cb) { cb.click(); return true; }
        } catch(e) { continue; }
    }
} catch(e) {}
return false;
    """, timeout=5)

    if clicked:
        print("[*] 已通过 JS contentDocument 点击 Turnstile")
        time.sleep(3)
        return True

    return False


# ============================================================
# 个人资料填写
# ============================================================


def build_profile() -> Tuple[str, str, str]:
    given_name = "Neo"
    family_name = "Lin"
    password = "N" + secrets.token_hex(4) + "!a7#" + secrets.token_urlsafe(6)
    return given_name, family_name, password


def fill_profile_and_submit(state: BrowserState, timeout: int = 120) -> Dict[str, str]:
    """填写个人资料并提交"""
    given_name, family_name, password = build_profile()
    deadline = time.time() + timeout
    turnstile_token = ""

    while time.time() < deadline:
        assert state.page is not None

        filled = safe_run_js(state, """
const givenName = arguments[0];
const familyName = arguments[1];
const password = arguments[2];

function isVisible(node) {
    if (!node) { return false; }
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
        return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
}

function pickInput(selector) {
    return Array.from(document.querySelectorAll(selector))
        .find(n => isVisible(n) && !n.disabled && !n.readOnly) || null;
}

function setInputValue(input, value) {
    if (!input) { return false; }
    input.focus(); input.click();
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    const tracker = input._valueTracker;
    if (tracker) { tracker.setValue(''); }
    if (setter) { setter.call(input, ''); setter.call(input, value); }
    else { input.value = ''; input.value = value; }
    input.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, data: value, inputType: 'insertText' }));
    input.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: value, inputType: 'insertText' }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    return String(input.value || '') === String(value || '');
}

const gi = pickInput('input[data-testid="givenName"], input[name="givenName"], input[autocomplete="given-name"]');
const fi = pickInput('input[data-testid="familyName"], input[name="familyName"], input[autocomplete="family-name"]');
const pi = pickInput('input[data-testid="password"], input[name="password"], input[type="password"]');

if (!gi || !fi || !pi) { return 'not-ready'; }

const ok = setInputValue(gi, givenName) && setInputValue(fi, familyName) && setInputValue(pi, password);
if (!ok) { return 'filled-failed'; }

return (
    String(gi.value||'').trim()===String(givenName||'').trim() &&
    String(fi.value||'').trim()===String(familyName||'').trim() &&
    String(pi.value||'')===String(password||'')
) ? 'filled' : 'verify-failed';
        """, given_name, family_name, password, timeout=8)

        if filled == 'not-ready':
            time.sleep(0.5)
            continue

        if filled != 'filled':
            print(f"[Debug] 资料填写失败：{filled}")
            time.sleep(0.5)
            continue

        # 检查 Turnstile 状态
        turnstile_state = safe_run_js(state, """
const inp = document.querySelector('input[name="cf-turnstile-response"]');
if (!inp) { return 'not-found'; }
return String(inp.value || '').trim() ? 'ready' : 'pending';
        """, timeout=3)

        if turnstile_state == "pending" and not turnstile_token:
            print("[*] 检测到 Turnstile，开始处理...")
            try:
                turnstile_token = get_turnstile_token(state)
            except Exception as e:
                raise Exception(f"Turnstile 处理失败：{e}")

            if turnstile_token:
                safe_run_js(state, """
const token = arguments[0];
const inp = document.querySelector('input[name="cf-turnstile-response"]');
if (!inp) { return false; }
const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
if (setter) { setter.call(inp, token); } else { inp.value = token; }
inp.dispatchEvent(new Event('input', { bubbles: true }));
inp.dispatchEvent(new Event('change', { bubbles: true }));
return String(inp.value || '').trim() === String(token || '').trim();
                """, turnstile_token, timeout=5)
                print("[*] Turnstile 响应已写入表单。")

        time.sleep(1.2)

        clicked = safe_run_js(state, r"""
const inp = document.querySelector('input[name="cf-turnstile-response"]');
if (inp && !String(inp.value || '').trim()) { return false; }

function isVisible(node) {
    if (!node) { return false; }
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
        return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
}

const submitButton = Array.from(document.querySelectorAll('button[type="submit"], button')).find(n => {
    if (!isVisible(n) || n.disabled || n.getAttribute('aria-disabled') === 'true') { return false; }
    const text = (n.innerText || n.textContent || '').replace(/\s+/g, '');
    const t = text.toLowerCase();
    return text === '完成注册' || text.includes('完成注册') ||
           t.includes('create account') || t.includes('sign up') || t.includes('complete');
});

if (!submitButton) { return false; }
submitButton.focus();
submitButton.click();
return true;
        """, timeout=5)

        if clicked:
            print(f"[*] 已填写注册资料并提交：{given_name} {family_name}")
            return {
                "given_name": given_name,
                "family_name": family_name,
                "password": password,
            }

        time.sleep(0.5)

    raise Exception("未找到最终注册表单或完成注册按钮")


# ============================================================
# SSO Cookie 处理
# ============================================================


def wait_for_sso_cookie(state: BrowserState, timeout: int = 120) -> str:
    deadline = time.time() + timeout
    last_seen_names: set = set()

    while time.time() < deadline:
        try:
            _get_active_page(state)
            if state.page is None:
                time.sleep(1)
                continue

            cookies = state.page.cookies(all_domains=True, all_info=True) or []
            for item in cookies:
                if isinstance(item, dict):
                    name = str(item.get("name", "")).strip()
                    value = str(item.get("value", "")).strip()
                else:
                    name = str(getattr(item, "name", "")).strip()
                    value = str(getattr(item, "value", "")).strip()

                if name:
                    last_seen_names.add(name)

                if name == "sso" and value:
                    print("[*] 已获取 sso cookie。")
                    return value

        except PageDisconnectedError:
            _get_active_page(state)
        except Exception:
            pass

        time.sleep(1)

    raise Exception(
        f"注册完成后未获取到 sso cookie，已见 cookie：{sorted(last_seen_names)}"
    )


def append_sso_to_txt(sso_value: str, output_path: Path) -> None:
    normalized = str(sso_value or "").strip()
    if not normalized:
        raise Exception("待写入的 sso 为空")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("a", encoding="utf-8") as f:
        f.write(normalized + "\n")

    print(f"[*] 已追加写入 sso：{output_path}")


# ============================================================
# Grok2API 推送
# ============================================================


def push_sso_to_api(tokens: List[str], config: AppConfig) -> None:
    if not config.api_endpoint or not config.api_token:
        print("[*] API 配置为空，跳过推送")
        return

    import urllib3
    import requests as req_lib
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    headers = {
        "Authorization": f"Bearer {config.api_token}",
        "Content-Type": "application/json",
    }

    tokens_to_push = [t for t in tokens if t]

    if config.api_append:
        try:
            get_resp = req_lib.get(
                config.api_endpoint, headers=headers, timeout=15, verify=False
            )
            if get_resp.status_code == 200:
                existing = get_resp.json().get("ssoBasic", [])
                existing_tokens = [
                    item["token"] if isinstance(item, dict) else str(item)
                    for item in existing if item
                ]
                seen: set = set()
                deduped: List[str] = []
                for t in existing_tokens + tokens_to_push:
                    if t not in seen:
                        seen.add(t)
                        deduped.append(t)
                tokens_to_push = deduped
                print(
                    f"[*] 线上 {len(existing_tokens)} 个，本次 {len(tokens)} 个，"
                    f"合并后 {len(deduped)} 个"
                )
            else:
                print(f"[Warn] 查询线上 token 失败：HTTP {get_resp.status_code}")
        except Exception as e:
            print(f"[Warn] 查询线上 token 异常：{e}")

    try:
        resp = req_lib.post(
            config.api_endpoint,
            json={"ssoBasic": tokens_to_push},
            headers=headers,
            timeout=60,
            verify=False,
        )
        if resp.status_code == 200:
            print(f"[*] SSO token 已推送（共 {len(tokens_to_push)} 个）：{config.api_endpoint}")
        else:
            print(f"[Warn] 推送 API 返回异常：HTTP {resp.status_code} {resp.text[:200]}")
    except Exception as e:
        print(f"[Warn] 推送 API 失败：{e}")


# ============================================================
# 单轮注册流程
# ============================================================


def run_single_registration(
    state: BrowserState,
    output_path: Path,
    config: AppConfig,
    logger: logging.Logger,
    round_num: int,
) -> RegistrationResult:
    try:
        open_signup_page(state, config)
        email, dev_token = fill_email_and_submit(state, timeout=config.email_timeout)
        fill_code_and_submit(state, email, dev_token, timeout=config.code_timeout)
        profile = fill_profile_and_submit(state, timeout=config.profile_timeout)
        sso_value = wait_for_sso_cookie(state, timeout=config.sso_timeout)
        append_sso_to_txt(sso_value, output_path)

        result = RegistrationResult(
            email=email,
            password=profile["password"],
            given_name=profile["given_name"],
            family_name=profile["family_name"],
            sso=sso_value,
            success=True
        )

        logger.info(
            f"注册成功 | round={round_num} email={email} "
            f"name={profile['given_name']} {profile['family_name']}"
        )
        print(f"[*] 本轮注册完成，邮箱：{email}")
        return result

    except Exception as e:
        logger.exception(f"第 {round_num} 轮注册失败：{e}")
        return RegistrationResult(
            email="", password="", given_name="", family_name="",
            sso="", success=False, error=str(e)
        )


# ============================================================
# 主入口
# ============================================================


def main() -> None:
    ensure_stable_python_runtime()
    warn_runtime_compatibility()

    config = AppConfig.load()
    logger = setup_logger(config)

    parser = argparse.ArgumentParser(description="xAI 自动注册并采集 sso")
    parser.add_argument(
        "--count", type=int, default=config.run_count,
        help=f"执行轮数，0 表示无限循环（默认 {config.run_count}）"
    )
    parser.add_argument("--output", default="sso/sso.txt", help="sso 输出文件路径")
    args = parser.parse_args()

    output_path = Path(args.output)
    options = setup_browser_options(config)
    state = BrowserState()
    state.user_data_dir = Path(__file__).parent / config.user_data_dir

    current_round = 0
    collected_sso: List[str] = []

    try:
        start_browser(options, state)

        while True:
            if args.count > 0 and current_round >= args.count:
                break

            current_round += 1
            print(f"\n[*] 开始第 {current_round} 轮注册")

            try:
                result = run_single_registration(
                    state=state,
                    output_path=output_path,
                    config=config,
                    logger=logger,
                    round_num=current_round,
                )

                if result.success and result.sso:
                    collected_sso.append(result.sso)

            except KeyboardInterrupt:
                print("\n[Info] 收到中断信号，停止。")
                break
            except Exception as error:
                print(f"[Error] 第 {current_round} 轮失败：{error}")
                logger.exception(f"轮次 {current_round} 异常")
            finally:
                restart_browser(options, state)

            if args.count == 0 or current_round < args.count:
                time.sleep(config.retry_delay)

    finally:
        if collected_sso:
            print(f"\n[*] 推送 {len(collected_sso)} 个 token 到 API...")
            push_sso_to_api(collected_sso, config)

        stop_browser(state)
        logger.info(
            f"程序执行完成 | total_rounds={current_round} success={len(collected_sso)}"
        )


if __name__ == "__main__":
    main()
