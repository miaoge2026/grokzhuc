"""
DuckMail 临时邮箱模块
提供邮箱创建、验证码获取功能，支持环境变量配置和结构化日志
"""

from __future__ import annotations

import json
import logging
import os
import random
import re
import string
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from curl_cffi import requests as curl_requests
    CURL_CFFI_AVAILABLE = True
except ImportError:
    CURL_CFFI_AVAILABLE = False

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ============================================================
# 配置管理
# ============================================================


@dataclass
class DuckMailConfig:
    """DuckMail 配置数据类"""
    api_base: str = "https://api.duckmail.sbs"
    bearer_token: str = ""
    proxy: str = ""
    request_timeout: int = 15
    max_retries: int = 3
    retry_backoff: float = 1.0

    @classmethod
    def load(cls) -> DuckMailConfig:
        """从环境变量和 config.json 加载配置，优先级：环境变量 > config.json > 默认值"""
        api_base = os.getenv("DUCKMAIL_API_BASE", "").strip()
        bearer = os.getenv("DUCKMAIL_BEARER", "").strip()
        proxy = os.getenv("HTTP_PROXY", os.getenv("HTTPS_PROXY", "")).strip()

        if not api_base or not bearer:
            config_path = Path(__file__).parent / "config.json"
            if config_path.exists():
                with config_path.open("r", encoding="utf-8") as f:
                    conf = json.load(f)
                if not api_base:
                    api_base = conf.get("duckmail_api_base", "https://api.duckmail.sbs")
                if not bearer:
                    bearer = conf.get("duckmail_bearer", "")
                if not proxy:
                    proxy = conf.get("proxy", "")

        return cls(api_base=api_base, bearer_token=bearer, proxy=proxy)


# ============================================================
# 日志配置
# ============================================================


def _setup_logger(name: str = "duckmail") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # 避免重复添加 handler

    logger.setLevel(logging.INFO)
    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"duckmail_{time.strftime('%Y%m%d')}.log"

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    return logger


logger = _setup_logger("duckmail")

# ============================================================
# 适配层接口（供 DrissionPage_example.py 调用）
# ============================================================

_temp_email_cache: Dict[str, str] = {}


def get_email_and_token() -> Tuple[Optional[str], Optional[str]]:
    """
    创建 DuckMail 临时邮箱并返回 (email, mail_token)

    Returns:
        Tuple[Optional[str], Optional[str]]: (邮箱地址，邮件 token) 或 (None, None)
    """
    try:
        email, _password, mail_token = create_temp_email()
        if email and mail_token:
            _temp_email_cache[email] = mail_token
            logger.info(f"邮箱创建成功：{email}")
            return email, mail_token
        logger.error("邮箱创建失败：返回值为空")
        return None, None
    except Exception as e:
        logger.exception(f"创建邮箱时发生异常：{e}")
        return None, None


def get_oai_code(dev_token: str, email: str, timeout: int = 120) -> Optional[str]:
    """
    轮询 DuckMail 获取 OTP 验证码

    Args:
        dev_token: 邮件访问 token
        email: 邮箱地址（用于日志）
        timeout: 超时时间（秒）

    Returns:
        Optional[str]: 验证码字符串（去除连字符）或 None
    """
    try:
        code = wait_for_verification_code(mail_token=dev_token, timeout=timeout)
        if code:
            code = code.replace("-", "")
            logger.info(f"验证码获取成功：email={email} code={code}")
            return code
        logger.warning(f"验证码获取超时：email={email} timeout={timeout}")
        return None
    except Exception as e:
        logger.exception(f"获取验证码时发生异常：email={email} error={e}")
        return None


# ============================================================
# HTTP 会话管理
# ============================================================


def _create_session(config: DuckMailConfig) -> Tuple[Any, bool]:
    """创建请求会话，优先使用 curl_cffi 进行 TLS 指纹伪装"""
    if CURL_CFFI_AVAILABLE:
        session = curl_requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        if config.proxy:
            session.proxies = {"http": config.proxy, "https": config.proxy}
        return session, True

    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    s = requests.Session()
    retry = Retry(
        total=config.max_retries,
        backoff_factor=config.retry_backoff,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"]
    )
    adapter = HTTPAdapter(max_retries=retry)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
        "Content-Type": "application/json",
    })
    if config.proxy:
        s.proxies = {"http": config.proxy, "https": config.proxy}
    return s, False


def _do_request(session: Any, use_cffi: bool, method: str, url: str,
                config: DuckMailConfig, **kwargs) -> Any:
    if use_cffi:
        kwargs.setdefault("impersonate", "chrome131")
    kwargs.setdefault("timeout", config.request_timeout)
    return getattr(session, method)(url, **kwargs)


# ============================================================
# 工具函数
# ============================================================


def _generate_password(length: int = 14) -> str:
    lower, upper, digits, special = (
        string.ascii_lowercase, string.ascii_uppercase,
        string.digits, "!@#$%"
    )
    pwd = [random.choice(lower), random.choice(upper),
           random.choice(digits), random.choice(special)]
    all_chars = lower + upper + digits + special
    pwd += [random.choice(all_chars) for _ in range(length - 4)]
    random.shuffle(pwd)
    return "".join(pwd)


def _validate_email_format(email: str) -> bool:
    return bool(re.match(r'^[a-z0-9]{8,13}@duckmail\.sbs$', email, re.IGNORECASE))


# ============================================================
# 核心功能
# ============================================================


def create_temp_email(config: Optional[DuckMailConfig] = None) -> Tuple[str, str, str]:
    """
    创建 DuckMail 临时邮箱

    Returns:
        Tuple[str, str, str]: (邮箱, 密码, mail_token)

    Raises:
        Exception: 创建失败时抛出
    """
    if config is None:
        config = DuckMailConfig.load()

    if not config.bearer_token:
        raise Exception("duckmail_bearer 未设置，无法创建临时邮箱")

    chars = string.ascii_lowercase + string.digits
    email_local = "".join(random.choice(chars) for _ in range(random.randint(8, 13)))
    email = f"{email_local}@duckmail.sbs"
    password = _generate_password()

    if not _validate_email_format(email):
        raise ValueError(f"生成的邮箱格式无效：{email}")

    api_base = config.api_base.rstrip("/")
    bearer_headers = {"Authorization": f"Bearer {config.bearer_token}"}
    session, use_cffi = _create_session(config)

    try:
        logger.info("正在创建邮箱账号")
        res = _do_request(session, use_cffi, "post",
                          f"{api_base}/accounts", config=config,
                          json={"address": email, "password": password},
                          headers=bearer_headers)

        if res.status_code not in (200, 201):
            raise Exception(f"创建邮箱失败：HTTP {res.status_code} - {res.text[:200]}")

        time.sleep(0.5)
        logger.info("正在获取邮件 Token")
        token_res = _do_request(session, use_cffi, "post",
                                f"{api_base}/token", config=config,
                                json={"address": email, "password": password})

        if token_res.status_code == 200:
            mail_token = token_res.json().get("token")
            if mail_token:
                logger.info("邮箱创建成功")
                return email, password, mail_token

        raise Exception(f"获取邮件 Token 失败：HTTP {token_res.status_code}")

    except Exception as e:
        logger.exception(f"创建邮箱过程中发生异常：{e}")
        raise Exception(f"DuckMail 创建邮箱失败：{e}")


def fetch_emails(mail_token: str,
                 config: Optional[DuckMailConfig] = None) -> List[Dict[str, Any]]:
    """获取邮件列表"""
    if config is None:
        config = DuckMailConfig.load()
    try:
        api_base = config.api_base.rstrip("/")
        headers = {"Authorization": f"Bearer {mail_token}"}
        session, use_cffi = _create_session(config)
        res = _do_request(session, use_cffi, "get",
                          f"{api_base}/messages", config=config, headers=headers)
        if res.status_code == 200:
            data = res.json()
            return data.get("hydra:member") or data.get("member") or data.get("data") or []
    except Exception:
        pass
    return []


def fetch_email_detail(mail_token: str, msg_id: str,
                       config: Optional[DuckMailConfig] = None) -> Optional[Dict]:
    """获取单封邮件详情"""
    if config is None:
        config = DuckMailConfig.load()
    try:
        api_base = config.api_base.rstrip("/")
        headers = {"Authorization": f"Bearer {mail_token}"}
        session, use_cffi = _create_session(config)

        if isinstance(msg_id, str) and msg_id.startswith("/messages/"):
            msg_id = msg_id.split("/")[-1]

        res = _do_request(session, use_cffi, "get",
                          f"{api_base}/messages/{msg_id}", config=config, headers=headers)
        if res.status_code == 200:
            return res.json()
    except Exception:
        pass
    return None


def wait_for_verification_code(
    mail_token: str,
    timeout: int = 120,
    poll_interval: float = 3.0,
    config: Optional[DuckMailConfig] = None
) -> Optional[str]:
    """轮询等待验证码邮件"""
    start_time = time.time()
    seen_ids: set = set()
    poll_count = 0

    logger.info(f"开始轮询验证码，超时={timeout}s")

    while time.time() - start_time < timeout:
        poll_count += 1
        messages = fetch_emails(mail_token, config)

        for msg in messages:
            if not isinstance(msg, dict):
                continue
            msg_id = msg.get("id") or msg.get("@id")
            if not msg_id or msg_id in seen_ids:
                continue
            seen_ids.add(msg_id)

            detail = fetch_email_detail(mail_token, str(msg_id), config)
            if detail:
                content = detail.get("text") or detail.get("html") or ""
                code = extract_verification_code(content)
                if code:
                    elapsed = time.time() - start_time
                    logger.info(f"验证码提取成功：{code} (耗时 {elapsed:.1f}s)")
                    return code

        time.sleep(poll_interval)

    logger.warning(f"验证码轮询超时，共轮询 {poll_count} 次")
    return None


def extract_verification_code(content: str) -> Optional[str]:
    """
    从邮件内容提取验证码。
    支持：Grok 格式 XXX-XXX、带标签格式、6 位纯数字。
    """
    if not content:
        return None

    # 模式 1: Grok 格式 XXX-XXX
    m = re.search(r"(?<![A-Z0-9-])([A-Z0-9]{3}-[A-Z0-9]{3})(?![A-Z0-9-])", content)
    if m:
        return m.group(1)

    # 模式 2: 带标签的验证码
    m = re.search(
        r"(?:verification code|验证码|your code)[:\s]*[<>\s]*([A-Z0-9]{3}-[A-Z0-9]{3})\b",
        content, re.IGNORECASE
    )
    if m:
        return m.group(1)

    # 模式 3: HTML 样式包裹
    m = re.search(
        r"background-color:\s*#F3F3F3[^>]*>[\s\S]*?([A-Z0-9]{3}-[A-Z0-9]{3})[\s\S]*?</p>",
        content
    )
    if m:
        return m.group(1)

    # 模式 4: Subject 行 6 位数字
    m = re.search(r"Subject:.*?(\d{6})", content)
    if m and m.group(1) != "177010":
        return m.group(1)

    # 模式 5: HTML 标签内 6 位数字
    for code in re.findall(r">\s*(\d{6})\s*<", content):
        if code != "177010":
            return code

    # 模式 6: 独立 6 位数字
    for code in re.findall(r"(?<![&#\d])(\d{6})(?![&#\d])", content):
        if code != "177010":
            return code

    return None


# ============================================================
# 模块入口（测试用）
# ============================================================

if __name__ == "__main__":
    config = DuckMailConfig.load()
    token_preview = config.bearer_token[:8] if config.bearer_token else "未设置"
    print(f"配置加载：API={config.api_base}, Token={token_preview}...")

    try:
        email, password, token = create_temp_email(config)
        print(f"邮箱创建：{email}")
        code = wait_for_verification_code(token)
        print(f"验证码：{code}")
    except Exception as e:
        print(f"测试失败：{e}")
