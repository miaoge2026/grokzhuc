/**
 * Turnstile Patcher v2.2
 * 修复 CDP 环境下 MouseEvent.screenX/screenY 缺失问题
 * 同时隐藏 navigator.webdriver 等自动化检测特征
 */
(function () {
    'use strict';

    function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    const screenX = getRandomInt(800, 1200);
    const screenY = getRandomInt(400, 600);

    try {
        Object.defineProperty(MouseEvent.prototype, 'screenX', {
            get: function () { return screenX; },
            configurable: true,
        });
        Object.defineProperty(MouseEvent.prototype, 'screenY', {
            get: function () { return screenY; },
            configurable: true,
        });
    } catch (e) {}

    try {
        Object.defineProperty(navigator, 'webdriver', {
            get: function () { return undefined; },
            configurable: true,
        });
    } catch (e) {}

    try {
        if (navigator.plugins.length === 0) {
            Object.defineProperty(navigator, 'plugins', {
                get: function () { return [1, 2, 3, 4, 5]; },
                configurable: true,
            });
        }
    } catch (e) {}

    window.__turnstilePatchApplied = true;
})();
