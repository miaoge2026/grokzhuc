#!/bin/bash
set -e

# 启动 Xvfb 虚拟显示器
Xvfb :99 -screen 0 1280x800x24 -nolisten tcp &
XVFB_PID=$!
export DISPLAY=:99

# 等待 Xvfb 就绪
sleep 1

# 传入 REGISTER_COUNT 时作为 --count 参数
EXTRA_ARGS=""
if [ -n "$REGISTER_COUNT" ]; then
    EXTRA_ARGS="--count $REGISTER_COUNT"
fi

# 运行主程序
python DrissionPage_example.py $EXTRA_ARGS "$@"

# 清理
kill $XVFB_PID 2>/dev/null || true
