#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
echo -e "${GREEN}=== Grok 注册工具 Docker 启动 ===${NC}"

if [ ! -f "config.json" ]; then
    echo -e "${YELLOW}警告：config.json 不存在，从 config.example.json 复制${NC}"
    cp config.example.json config.json
    echo -e "${YELLOW}请编辑 config.json 填写 DuckMail Bearer Token${NC}"
    exit 1
fi

if [ -z "$DUCKMAIL_BEARER" ]; then
    echo -e "${RED}错误：DUCKMAIL_BEARER 环境变量未设置${NC}"
    echo "用法：export DUCKMAIL_BEARER=your_token && ./scripts/docker-run.sh [轮数]"
    exit 1
fi

COUNT="${1:-}"
if [ -n "$COUNT" ]; then
    echo -e "${GREEN}注册轮数：$COUNT${NC}"
    export REGISTER_COUNT="$COUNT"
fi

if ! docker images grok-register | grep -q grok-register; then
    echo -e "${YELLOW}首次构建 Docker 镜像...${NC}"
    docker-compose build
fi

echo -e "${GREEN}启动容器...${NC}"
docker-compose up --remove-orphans
echo -e "${GREEN}=== 完成 ===${NC}"
echo -e "SSO token: ${GREEN}sso/${NC}  运行日志：${GREEN}logs/${NC}"
