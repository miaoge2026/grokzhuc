#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$(dirname "$SCRIPT_DIR")"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
echo -e "${GREEN}=== 构建 Grok 注册工具 Docker 镜像 ===${NC}"

NO_CACHE=""
if [ "$1" = "--no-cache" ]; then
    NO_CACHE="--no-cache"
    echo -e "${YELLOW}使用 --no-cache 模式${NC}"
fi

docker-compose build $NO_CACHE
echo -e "${GREEN}=== 构建完成 ===${NC}"
docker images grok-register
